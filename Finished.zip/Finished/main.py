from bulkTransCrypto import BulkTransCrypto

my_bulkTrans = BulkTransCrypto()
my_bulkTrans.run()